//
//  City.h
//  anywayanyday
//
//  Created by Юлия on 26.07.15.
//  Copyright (c) 2015 yulia. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface City : NSObject
@property (strong, nonatomic) NSString *cityName;
@property (strong, nonatomic) NSString *countryName;
@property (strong, nonatomic) NSString *cityCode;
@end
