//
//  Fare.m
//  anywayanyday
//
//  Created by Юлия on 29.07.15.
//  Copyright (c) 2015 yulia. All rights reserved.
//

#import "Fare.h"

@implementation Fare

@end
