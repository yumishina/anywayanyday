//
//  Fare+Actions.h
//  anywayanyday
//
//  Created by Юлия on 30.07.15.
//  Copyright (c) 2015 yulia. All rights reserved.
//

#import "Fare.h"

@interface Fare (Actions)
+(NSMutableArray*)parseFaresWithData:(NSArray*)data;
@end
