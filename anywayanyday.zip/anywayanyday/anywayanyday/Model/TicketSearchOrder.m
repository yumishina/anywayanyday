//
//  TicketSearchOrder.m
//  anywayanyday
//
//  Created by Юлия on 28.07.15.
//  Copyright (c) 2015 yulia. All rights reserved.
//

#import "TicketSearchOrder.h"

@implementation TicketSearchOrder

@end
