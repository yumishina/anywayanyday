//
//  City+Actions.h
//  anywayanyday
//
//  Created by Юлия on 26.07.15.
//  Copyright (c) 2015 yulia. All rights reserved.
//

#import "City.h"

@interface City (Actions)
+(NSMutableArray*)parseCitiesWithData:(NSArray*)data;
@end
