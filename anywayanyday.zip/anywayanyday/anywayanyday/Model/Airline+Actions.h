//
//  Airline+Actions.h
//  anywayanyday
//
//  Created by Юлия on 30.07.15.
//  Copyright (c) 2015 yulia. All rights reserved.
//

#import "Airline.h"

@interface Airline (Actions)
+(NSMutableArray*)parseAirlinesWithData:(NSArray*)data;
@end
