//
//  AirlineCell.m
//  anywayanyday
//
//  Created by Юлия on 30.07.15.
//  Copyright (c) 2015 yulia. All rights reserved.
//

#import "AirlineCell.h"

@implementation AirlineCell

@end
